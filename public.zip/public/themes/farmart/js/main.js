/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./platform/core/base/resources/sass/components/crop-image.scss":
/*!**********************************************************************!*\
  !*** ./platform/core/base/resources/sass/components/crop-image.scss ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/base/resources/sass/components/error-pages.scss":
/*!***********************************************************************!*\
  !*** ./platform/core/base/resources/sass/components/error-pages.scss ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/base/resources/sass/components/tree-category.scss":
/*!*************************************************************************!*\
  !*** ./platform/core/base/resources/sass/components/tree-category.scss ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/base/resources/sass/core.scss":
/*!*****************************************************!*\
  !*** ./platform/core/base/resources/sass/core.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/base/resources/sass/libraries/select2/select2.scss":
/*!**************************************************************************!*\
  !*** ./platform/core/base/resources/sass/libraries/select2/select2.scss ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/media/resources/sass/media.scss":
/*!*******************************************************!*\
  !*** ./platform/core/media/resources/sass/media.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/setting/resources/sass/admin-email.scss":
/*!***************************************************************!*\
  !*** ./platform/core/setting/resources/sass/admin-email.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/core/table/resources/sass/table.scss":
/*!*******************************************************!*\
  !*** ./platform/core/table/resources/sass/table.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/get-started/resources/sass/get-started.scss":
/*!***********************************************************************!*\
  !*** ./platform/packages/get-started/resources/sass/get-started.scss ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/installer/resources/sass/style.scss":
/*!***************************************************************!*\
  !*** ./platform/packages/installer/resources/sass/style.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/menu/resources/sass/menu.scss":
/*!*********************************************************!*\
  !*** ./platform/packages/menu/resources/sass/menu.scss ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/revision/resources/sass/revision.scss":
/*!*****************************************************************!*\
  !*** ./platform/packages/revision/resources/sass/revision.scss ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/seo-helper/resources/sass/seo-helper.scss":
/*!*********************************************************************!*\
  !*** ./platform/packages/seo-helper/resources/sass/seo-helper.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/shortcode/resources/sass/shortcode.scss":
/*!*******************************************************************!*\
  !*** ./platform/packages/shortcode/resources/sass/shortcode.scss ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/slug/resources/sass/slug.scss":
/*!*********************************************************!*\
  !*** ./platform/packages/slug/resources/sass/slug.scss ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/theme/resources/sass/admin-bar.scss":
/*!***************************************************************!*\
  !*** ./platform/packages/theme/resources/sass/admin-bar.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/theme/resources/sass/guideline.scss":
/*!***************************************************************!*\
  !*** ./platform/packages/theme/resources/sass/guideline.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/theme/resources/sass/theme-options.scss":
/*!*******************************************************************!*\
  !*** ./platform/packages/theme/resources/sass/theme-options.scss ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/packages/widget/resources/sass/widget.scss":
/*!*************************************************************!*\
  !*** ./platform/packages/widget/resources/sass/widget.scss ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/backup/resources/sass/backup.scss":
/*!************************************************************!*\
  !*** ./platform/plugins/backup/resources/sass/backup.scss ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/contact/resources/sass/contact-public.scss":
/*!*********************************************************************!*\
  !*** ./platform/plugins/contact/resources/sass/contact-public.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/contact/resources/sass/contact.scss":
/*!**************************************************************!*\
  !*** ./platform/plugins/contact/resources/sass/contact.scss ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/currencies.scss":
/*!*******************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/currencies.scss ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/customer.scss":
/*!*****************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/customer.scss ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/ecommerce-product-attributes.scss":
/*!*************************************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/ecommerce-product-attributes.scss ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/ecommerce.scss":
/*!******************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/ecommerce.scss ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-auth.scss":
/*!*******************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-auth.scss ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-ecommerce-missing-bootstrap.scss":
/*!******************************************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-ecommerce-missing-bootstrap.scss ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-ecommerce-rtl.scss":
/*!****************************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-ecommerce-rtl.scss ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-ecommerce.scss":
/*!************************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-ecommerce.scss ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-faq.scss":
/*!******************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-faq.scss ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-review.scss":
/*!*********************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-review.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-theme-rtl.scss":
/*!************************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-theme-rtl.scss ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/front-theme.scss":
/*!********************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/front-theme.scss ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/order-return.scss":
/*!*********************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/order-return.scss ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/report.scss":
/*!***************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/report.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/review.scss":
/*!***************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/review.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/ecommerce/resources/sass/widget.scss":
/*!***************************************************************!*\
  !*** ./platform/plugins/ecommerce/resources/sass/widget.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/faq/resources/sass/faq.scss":
/*!******************************************************!*\
  !*** ./platform/plugins/faq/resources/sass/faq.scss ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/fob-floating-buttons/resources/sass/fob-floating-buttons.scss":
/*!****************************************************************************************!*\
  !*** ./platform/plugins/fob-floating-buttons/resources/sass/fob-floating-buttons.scss ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/language/resources/sass/language-public.scss":
/*!***********************************************************************!*\
  !*** ./platform/plugins/language/resources/sass/language-public.scss ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/language/resources/sass/language.scss":
/*!****************************************************************!*\
  !*** ./platform/plugins/language/resources/sass/language.scss ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/log-viewer/resources/assets/sass/log-viewer.scss":
/*!***************************************************************************!*\
  !*** ./platform/plugins/log-viewer/resources/assets/sass/log-viewer.scss ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/marketplace/resources/sass/vendor-dashboard/marketplace-rtl.scss":
/*!*******************************************************************************************!*\
  !*** ./platform/plugins/marketplace/resources/sass/vendor-dashboard/marketplace-rtl.scss ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/marketplace/resources/sass/vendor-dashboard/marketplace.scss":
/*!***************************************************************************************!*\
  !*** ./platform/plugins/marketplace/resources/sass/vendor-dashboard/marketplace.scss ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/newsletter/resources/sass/newsletter.scss":
/*!********************************************************************!*\
  !*** ./platform/plugins/newsletter/resources/sass/newsletter.scss ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/payment/resources/sass/payment-setting.scss":
/*!**********************************************************************!*\
  !*** ./platform/plugins/payment/resources/sass/payment-setting.scss ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/payment/resources/sass/payment.scss":
/*!**************************************************************!*\
  !*** ./platform/plugins/payment/resources/sass/payment.scss ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/simple-slider/resources/sass/simple-slider.scss":
/*!**************************************************************************!*\
  !*** ./platform/plugins/simple-slider/resources/sass/simple-slider.scss ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/social-login/resources/sass/social-login.scss":
/*!************************************************************************!*\
  !*** ./platform/plugins/social-login/resources/sass/social-login.scss ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/toc/resources/assets/sass/toc.scss":
/*!*************************************************************!*\
  !*** ./platform/plugins/toc/resources/assets/sass/toc.scss ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/plugins/translation/resources/sass/translation.scss":
/*!**********************************************************************!*\
  !*** ./platform/plugins/translation/resources/sass/translation.scss ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/themes/farmart/assets/js/main.js":
/*!***************************************************!*\
  !*** ./platform/themes/farmart/assets/js/main.js ***!
  \***************************************************/
/***/ (() => {



var MartApp = MartApp || {};
window.MartApp = MartApp;
MartApp.$iconChevronLeft = '<span class="slick-prev-arrow svg-icon"><svg><use href="#svg-icon-chevron-left" xlink:href="#svg-icon-chevron-left"></use></svg></span>';
MartApp.$iconChevronRight = '<span class="slick-next-arrow svg-icon"><svg><use href="#svg-icon-chevron-right" xlink:href="#svg-icon-chevron-right"></use></svg></span>';
if (typeof ScrollBarHelper !== 'undefined') {
  window._scrollBar = new ScrollBarHelper();
}
MartApp.isRTL = $('body').prop('dir') === 'rtl';
(function ($) {
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });
  function basicEvents() {
    $('.form--quick-search .form-group--icon').show();
    var $categoryLabel = $('.product-category-label .text');
    $(document).on('change', '.product-category-select', function () {
      $categoryLabel.text($.trim($(this).find('option:selected').text()));
    });
    $categoryLabel.text($.trim($('.product-category-select option:selected').text()));
    $(document).ready(function () {
      $('.preloader').addClass('fade-in');
    });
  }
  function subMenuToggle() {
    $(document).on('click', '.menu-item-has-children > a > .sub-toggle', function (e) {
      e.preventDefault();
      var $this = $(this);
      var $parent = $this.closest('.menu-item-has-children');
      $parent.toggleClass('active');
    });
    $(document).on('click', '.mega-menu__column > a > .sub-toggle', function (e) {
      e.preventDefault();
      var $this = $(this);
      var $parent = $this.closest('.mega-menu__column');
      $parent.toggleClass('active');
    });
  }
  function siteToggleAction() {
    $('.toggle--sidebar').on('click', function (e) {
      e.preventDefault();
      var url = $(this).attr('href');
      $(this).toggleClass('active');
      $(this).siblings('a').removeClass('active');
      $(url).toggleClass('active');
      $(url).siblings('.panel--sidebar').removeClass('active');
      _scrollBar.hide();
    });
    $(document).on('click', '.close-toggle--sidebar', function (e) {
      e.preventDefault();
      var $panel;
      if ($(this).data('toggle-closest')) {
        $panel = $(this).closest($(this).data('toggle-closest'));
      }
      if (!$panel || !$panel.length) {
        $panel = $(this).closest('.panel--sidebar');
      }
      $panel.removeClass('active');
      _scrollBar.reset();
    });
    $('body').on('click', function (e) {
      if ($(e.target).siblings('.panel--sidebar').hasClass('active')) {
        $('.panel--sidebar').removeClass('active');
        _scrollBar.reset();
      }
    });
  }
  $(function () {
    basicEvents();
    subMenuToggle();
    siteToggleAction();
    window.addEventListener('ecommerce.categories-dropdown.loaded', function () {
      subMenuToggle();
    });
  });
  MartApp.showModal = function ($modal) {
    if (typeof $.fn.modal === 'function') {
      $modal.modal('show');
    } else {
      $modal.addClass('show');
      $modal.css('display', 'block');
      $modal.attr('aria-hidden', 'false');
      $('body').addClass('modal-open');
      if (!$('.modal-backdrop').length) {
        $('<div class="modal-backdrop fade show"></div>').appendTo('body');
      }
    }
  };
  MartApp.hideModal = function ($modal) {
    if (typeof $.fn.modal === 'function') {
      $modal.modal('hide');
    } else {
      $modal.removeClass('show');
      $modal.css('display', 'none');
      $modal.attr('aria-hidden', 'true');
      $('body').removeClass('modal-open');
      $('.modal-backdrop').remove();
    }
  };
  MartApp.initQuickShopVariationListeners = function ($modal) {
    var originalSuccessCallback = window.onChangeSwatchesSuccess;
    var originalPushState = window.history.pushState;
    var originalReplaceState = window.history.replaceState;
    window.history.pushState = function () {
      if (arguments[0] && arguments[0].product_attributes_id && $('#' + arguments[0].product_attributes_id).closest('#product-quick-shop-modal').length) {
        return;
      }
      return originalPushState.apply(window.history, arguments);
    };
    window.history.replaceState = function () {
      if (arguments[0] && arguments[0].product_attributes_id && $('#' + arguments[0].product_attributes_id).closest('#product-quick-shop-modal').length) {
        return;
      }
      return originalReplaceState.apply(window.history, arguments);
    };
    window.onChangeSwatchesSuccess = function (res, $productAttributes) {
      if (originalSuccessCallback && typeof originalSuccessCallback === 'function') {
        originalSuccessCallback(res, $productAttributes);
      }
      if ($productAttributes.closest('#product-quick-shop-modal').length) {
        var data = res.data;
        if (data) {
          var $availabilityStatus = $modal.find('.availability-status .status-value');
          var $addToCartBtn = $modal.find('.add-to-cart-button');
          var $quantityInput = $modal.find('input[name="qty"]');
          var inStockText = $availabilityStatus.data('in-stock-text') || 'In stock';
          var outOfStockText = $availabilityStatus.data('out-of-stock-text') || 'Out of stock';
          if (data.product && data.product.is_out_of_stock) {
            $availabilityStatus.html('<span class="text-danger">' + outOfStockText + '</span>');
            $addToCartBtn.addClass('disabled').prop('disabled', true);
            if ($quantityInput.length) {
              $quantityInput.prop('readonly', true);
            }
          } else if (data.product && data.product.with_storehouse_management && data.product.quantity < 1) {
            $availabilityStatus.html('<span class="text-danger">' + outOfStockText + '</span>');
            $addToCartBtn.addClass('disabled').prop('disabled', true);
            if ($quantityInput.length) {
              $quantityInput.prop('readonly', true);
            }
          } else {
            $availabilityStatus.html('<span class="text-success">' + inStockText + '</span>');
            $addToCartBtn.removeClass('disabled').prop('disabled', false);
            if ($quantityInput.length) {
              $quantityInput.prop('readonly', false);
            }
          }
        }
      }
    };
    $modal.on('hidden.bs.modal', function () {
      window.onChangeSwatchesSuccess = originalSuccessCallback;
      window.history.pushState = originalPushState;
      window.history.replaceState = originalReplaceState;
    });
  };
  MartApp.updateQuickShopAvailability = function ($modal) {
    var $form = $modal.find('form.cart-form');
    var $availabilityStatus = $modal.find('.availability-status .status-value');
    var $addToCartBtn = $form.find('.add-to-cart-button');
    var $quantityInput = $form.find('input[name="qty"]');
    if (!$availabilityStatus.length) {
      return;
    }
    var isOutOfStock = $addToCartBtn.hasClass('disabled') || $addToCartBtn.prop('disabled');
    var inStockText = $availabilityStatus.data('in-stock-text') || 'In stock';
    var outOfStockText = $availabilityStatus.data('out-of-stock-text') || 'Out of stock';
    if (isOutOfStock) {
      $availabilityStatus.html('<span class="text-danger">' + outOfStockText + '</span>');
      if ($quantityInput.length) {
        $quantityInput.prop('readonly', true);
      }
    } else {
      $availabilityStatus.html('<span class="text-success">' + inStockText + '</span>');
      if ($quantityInput.length) {
        $quantityInput.prop('readonly', false);
      }
    }
  };
  MartApp.init = function () {
    MartApp.$body = $(document.body);
    MartApp.formSearch = '.bb-product-form-filter';
    MartApp.$formSearch = $(document).find(MartApp.formSearch);
    MartApp.productListing = '.products-listing';
    MartApp.$productListing = $(MartApp.productListing);
    this.lazyLoad(null, true);
    this.productQuickView();
    this.productQuickShop();
    this.slickSlides();
    this.productQuantity();
    this.addProductToWishlist();
    this.addProductToCompare();
    this.addProductToCart();
    this.applyCouponCode();
    this.productGallery();
    this.lightBox();
    this.handleTabBootstrap();
    this.toggleViewProducts();
    this.filterSlider();
    this.toolbarOrderingProducts();
    this.productsFilter();
    this.ajaxUpdateCart();
    this.removeCartItem();
    this.removeWishlistItem();
    this.removeCompareItem();
    this.customerDashboard();
    this.newsletterForm();
    this.contactSellerForm();
    this.stickyAddToCart();
    this.backToTop();
    this.stickyHeader();
    this.recentlyViewedProducts();
    MartApp.$body.on('click', '.catalog-sidebar .backdrop, #cart-mobile .backdrop', function (e) {
      e.preventDefault();
      $(this).parent().removeClass('active');
      _scrollBar.reset();
    });
    MartApp.$body.on('click', '.sidebar-filter-mobile', function (e) {
      e.preventDefault();
      MartApp.toggleSidebarFilterProducts('open', $(e.currentTarget).data('toggle'));
    });
    MartApp.$body.on('click', '.ps-layout__left .ps-btn--close, .screen-darken', function (e) {
      e.preventDefault();
      MartApp.toggleSidebarFilterProducts('close');
    });
    this.initCountdowns();
  };
  MartApp.toggleSidebarFilterProducts = function () {
    var status = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'close';
    var target = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'product-categories-primary-sidebar';
    var $el = $('[data-toggle-target="' + target + '"]');
    if (!$el.length) {
      $el = $('.ps-layout__left');
    }
    if (status === 'close') {
      $el.removeClass('active');
      _scrollBar.reset();
    } else {
      $el.addClass('active');
      _scrollBar.hide();
    }
  };
  MartApp.productQuickView = function () {
    var $modal = $('#product-quick-view-modal');
    MartApp.$body.on('click', '.product-quick-view-button .quick-view', function (e) {
      e.preventDefault();
      var _self = $(e.currentTarget);
      _self.addClass('loading');
      $modal.removeClass('loaded').addClass('loading');
      $modal.modal('show');
      $modal.find('.product-modal-content').html('');
      $.ajax({
        url: _self.data('url'),
        type: 'GET',
        success: function success(res) {
          if (!res.error) {
            $modal.find('.product-modal-content').html(res.data);
            setTimeout(function () {
              if (typeof EcommerceApp !== 'undefined') {
                EcommerceApp.initProductGallery(true);
              }
              MartApp.lazyLoad($modal[0]);
            }, 100);
            if (typeof Theme.lazyLoadInstance !== 'undefined') {
              Theme.lazyLoadInstance.update();
            }
            document.dispatchEvent(new CustomEvent('ecommerce.quick-view.initialized'));
          }
        },
        error: function error() {},
        complete: function complete() {
          $modal.addClass('loaded').removeClass('loading');
          _self.removeClass('loading');
        }
      });
    });
  };
  MartApp.productQuickShop = function () {
    MartApp.$body.on('click', '.js-quick-shop-button', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var $btn = $(this);
      var $modal = $('#product-quick-shop-modal');
      if ($btn.hasClass('loading')) {
        return;
      }
      $btn.addClass('loading');
      $modal.removeClass('loaded').addClass('loading');
      MartApp.showModal($modal);
      $.ajax({
        url: $btn.data('url'),
        type: 'GET',
        success: function success(res) {
          if (!res.error) {
            $modal.find('.product-quick-shop-content').html(res.data);
            $modal.find('form.cart-form').addClass('quick-shop-form');
            if (!$modal.find('.product-attributes').length && $modal.find('.attribute-swatches-wrapper').length) {
              $modal.find('.ps-product--quickshop').addClass('product-attributes');
            }
            if (typeof window.ChangeProductSwatches !== 'undefined') {
              $modal.find('.attribute-swatches-wrapper input:checked').trigger('change');
            }
            if (typeof MartApp.initProductQuantity === 'function') {
              MartApp.initProductQuantity($modal);
            }
            MartApp.initQuickShopVariationListeners($modal);
            MartApp.updateQuickShopAvailability($modal);
          } else {
            MartApp.showError(res.message);
            MartApp.hideModal($modal);
          }
        },
        error: function error(res) {
          MartApp.handleError(res);
          $modal.modal('hide');
        },
        complete: function complete() {
          $modal.addClass('loaded').removeClass('loading');
          $btn.removeClass('loading');
        }
      });
    });
    MartApp.$body.on('click', '#product-quick-shop-modal .btn-close', function (e) {
      e.preventDefault();
      MartApp.hideModal($('#product-quick-shop-modal'));
    });
    MartApp.$body.on('click', '.modal-backdrop', function (e) {
      e.preventDefault();
      MartApp.hideModal($('#product-quick-shop-modal'));
    });
    MartApp.$body.on('click', '.quick-shop-form button[type=submit]', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var $btn = $(this);
      var $form = $btn.closest('form.cart-form');
      var $modal = $('#product-quick-shop-modal');
      $btn.addClass('loading');
      var data = $form.serializeArray();
      data.push({
        name: 'checkout',
        value: $btn.prop('name') === 'checkout' ? 1 : 0
      });
      $.ajax({
        type: 'POST',
        url: $form.prop('action'),
        data: $.param(data),
        success: function success(res) {
          if (res.error) {
            MartApp.showError(res.message);
            if (res.data && res.data.next_url !== undefined) {
              setTimeout(function () {
                window.location.href = res.data.next_url;
              }, 500);
            }
            return false;
          }
          if (res.data && res.data.next_url !== undefined) {
            window.location.href = res.data.next_url;
            return false;
          }
          MartApp.hideModal($modal);
          MartApp.showSuccess(res.message);
          MartApp.loadAjaxCart();
        },
        error: function error(res) {
          MartApp.handleError(res, $form);
        },
        complete: function complete() {
          $btn.removeClass('loading');
        }
      });
    });
  };
  MartApp.productGallery = function (destroy, $gallery) {
    if (!$gallery || !$gallery.length) {
      $gallery = $('.product-gallery');
    }
    if ($gallery.length) {
      var first = $gallery.find('.product-gallery__wrapper');
      var second = $gallery.find('.product-gallery__variants');
      if (destroy) {
        if (first.length && first.hasClass('slick-initialized')) {
          first.slick('unslick');
        }
        if (second.length && second.hasClass('slick-initialized')) {
          second.slick('unslick');
        }
      }
      first.not('.slick-initialized').slick({
        rtl: MartApp.isRTL,
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: false,
        asNavFor: second,
        dots: false,
        prevArrow: MartApp.$iconChevronLeft,
        nextArrow: MartApp.$iconChevronRight,
        lazyLoad: 'ondemand'
      });
      second.not('.slick-initialized').slick({
        rtl: MartApp.isRTL,
        slidesToShow: 8,
        slidesToScroll: 1,
        infinite: false,
        focusOnSelect: true,
        asNavFor: first,
        vertical: true,
        prevArrow: '<span class="slick-prev-arrow svg-icon"><svg><use href="#svg-icon-arrow-up" xlink:href="#svg-icon-arrow-up"></use></svg></span>',
        nextArrow: '<span class="slick-next-arrow svg-icon"><svg><use href="#svg-icon-chevron-down" xlink:href="#svg-icon-chevron-down"></use></svg></span>',
        responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 6,
            vertical: false
          }
        }, {
          breakpoint: 480,
          settings: {
            slidesToShow: 3,
            vertical: false
          }
        }]
      });
    }
  };
  MartApp.lightBox = function () {
    var $productGallery = $('.product-gallery--with-images');
    if ($productGallery.data('lightGallery')) {
      $productGallery.data('lightGallery').destroy(true);
    }
    $productGallery.lightGallery({
      selector: '.item a',
      thumbnail: true,
      share: false,
      fullScreen: false,
      autoplay: false,
      autoplayControls: false,
      actualSize: false
    });
    var $galleries = $('.review-images-total.review-images');
    if ($galleries.length) {
      $galleries.map(function (index, value) {
        if (!$(value).data('lightGallery')) {
          $(value).lightGallery({
            selector: 'a',
            thumbnail: true,
            share: false,
            fullScreen: false,
            autoplay: false,
            autoplayControls: false,
            actualSize: false
          });
        }
      });
    }
  };
  MartApp.slickSlide = function (el) {
    var $el = $(el);
    if ($el.length && !$el.hasClass('slick-initialized')) {
      if (!$el.is(':visible') || $el.children().length === 0) {
        return;
      }
      var slickOptions = $el.data('slick') || {};
      if (slickOptions.appendArrows) {
        var $arrows = $el.parent().find(slickOptions.appendArrows);
        if ($arrows.length) {
          slickOptions.appendArrows = $arrows;
        }
      }
      slickOptions = Object.assign(slickOptions, {
        rtl: MartApp.isRTL,
        prevArrow: MartApp.$iconChevronLeft,
        nextArrow: MartApp.$iconChevronRight
      });
      try {
        $el.slick(slickOptions);
      } catch (error) {
        console.warn('Failed to initialize slick slider:', error);
      }
    }
  };
  MartApp.slickSlides = function () {
    $('.slick-slides-carousel').not('.slick-initialized').map(function (i, e) {
      MartApp.slickSlide(e);
    });
  };
  MartApp.safeSlickInit = function (selector) {
    var $elements = $(selector).not('.slick-initialized');
    $elements.each(function () {
      var $el = $(this);
      var $images = $el.find('img');
      if ($images.length === 0 || $images.filter(function () {
        return this.complete;
      }).length === $images.length) {
        MartApp.slickSlide(this);
      } else {
        var loadedCount = 0;
        var totalImages = $images.length;
        $images.on('load error', function () {
          loadedCount++;
          if (loadedCount === totalImages && !$el.hasClass('slick-initialized')) {
            MartApp.slickSlide($el[0]);
          }
        });
      }
    });
  };
  MartApp.initCountdowns = function () {
    var $countdownElements = $('.expire-countdown').not('[data-initialized]');
    if ($countdownElements.length > 0) {
      if (typeof $.fn.expireCountdown === 'function') {
        $countdownElements.each(function () {
          var $this = $(this);
          $this.attr('data-initialized', 'true');
          $this.expireCountdown();
        });
      } else {
        if (typeof window.expireCountdownInit === 'undefined') {
          window.expireCountdownInit = true;
          setTimeout(function () {
            if (typeof $.fn.expireCountdown === 'function') {
              MartApp.initCountdowns();
            }
          }, 500);
        }
      }
    }
  };
  MartApp.lazyLoad = function (container) {
    var init = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    if (init) {
      MartApp.lazyLoadInstance = new LazyLoad({
        elements_selector: '.lazyload',
        callback_error: function callback_error(img) {
          img.setAttribute('src', siteConfig.img_placeholder);
        }
      });
    } else {
      new LazyLoad({
        container: container,
        elements_selector: '.lazyload',
        callback_error: function callback_error(img) {
          img.setAttribute('src', siteConfig.img_placeholder);
        }
      });
    }
  };
  MartApp.productQuantity = function () {
    MartApp.$body.on('click', '.quantity .increase, .quantity .decrease', function (e) {
      e.preventDefault();
      var $this = $(this),
        $wrapperBtn = $this.closest('.product-button'),
        $btn = $wrapperBtn.find('.quantity_button'),
        $price = $this.closest('.quantity').siblings('.box-price').find('.price-current'),
        $priceCurrent = $price.html(),
        $qty = $this.siblings('.qty'),
        step = parseInt($qty.attr('step'), 10),
        current = parseInt($qty.val(), 10),
        min = parseInt($qty.attr('min'), 10),
        max = parseInt($qty.attr('max'), 10);
      min = min || 1;
      max = max || current + 1;
      if ($this.hasClass('decrease') && current > min) {
        $qty.val(current - step);
        $qty.trigger('change');
        var numQuantity = +$btn.attr('data-quantity');
        numQuantity = numQuantity - 1;
        $btn.attr('data-quantity', numQuantity);
        var $total2 = ($priceCurrent * 1 - $priceCurrent / current).toFixed(2);
        $price.html($total2);
      }
      if ($this.hasClass('increase') && current < max) {
        $qty.val(current + step);
        $qty.trigger('change');
        var _numQuantity = +$btn.attr('data-quantity');
        _numQuantity = _numQuantity + 1;
        $btn.attr('data-quantity', _numQuantity);
        var $total = ($priceCurrent * 1 + $priceCurrent / current).toFixed(2);
        $price.html($total);
      }
      MartApp.processUpdateCart($this);
    });
    MartApp.$body.on('keyup', '.quantity .qty', function (e) {
      e.preventDefault();
      var $this = $(this),
        $wrapperBtn = $this.closest('.product-button'),
        $btn = $wrapperBtn.find('.quantity_button'),
        $price = $this.closest('.quantity').siblings('.box-price').find('.price-current'),
        $priceFirst = $price.data('current'),
        current = parseInt($this.val(), 10),
        min = parseInt($this.attr('min'), 10),
        max = parseInt($this.attr('max'), 10);
      var min_check = min ? min : 1;
      var max_check = max ? max : current + 1;
      if (current <= max_check && current >= min_check) {
        $btn.attr('data-quantity', current);
        var $total = ($priceFirst * current).toFixed(2);
        $price.html($total);
      }
      MartApp.processUpdateCart($this);
    });
  };
  MartApp.addProductToWishlist = function () {
    MartApp.$body.on('click', '.wishlist-button .wishlist', function (e) {
      e.preventDefault();
      var $btn = $(e.currentTarget);
      $btn.addClass('loading');
      $.ajax({
        url: $btn.data('url'),
        method: 'POST',
        success: function success(res) {
          var _res$data;
          if (res.error) {
            MartApp.showError(res.message);
            return false;
          }
          MartApp.showSuccess(res.message);
          $('.btn-wishlist .header-item-counter').text(res.data.count);
          if ((_res$data = res.data) !== null && _res$data !== void 0 && _res$data.added) {
            $('.wishlist-button .wishlist[data-url="' + $btn.data('url') + '"]').addClass('added-to-wishlist');
          } else {
            $('.wishlist-button .wishlist[data-url="' + $btn.data('url') + '"]').removeClass('added-to-wishlist');
          }
        },
        error: function error(res) {
          MartApp.showError(res.message);
        },
        complete: function complete() {
          $btn.removeClass('loading');
        }
      });
    });
  };
  MartApp.addProductToCompare = function () {
    MartApp.$body.on('click', '.compare-button .compare', function (e) {
      e.preventDefault();
      var $btn = $(e.currentTarget);
      $btn.addClass('loading');
      $.ajax({
        url: $btn.data('url'),
        method: 'POST',
        success: function success(res) {
          if (res.error) {
            MartApp.showError(res.message);
            return false;
          }
          MartApp.showSuccess(res.message);
          $('.btn-compare .header-item-counter').text(res.data.count);
        },
        error: function error(res) {
          MartApp.showError(res.message);
        },
        complete: function complete() {
          $btn.removeClass('loading');
        }
      });
    });
  };
  MartApp.addProductToCart = function () {
    MartApp.$body.on('click', 'form.cart-form button[type=submit]', function (e) {
      e.preventDefault();
      var $form = $(this).closest('form.cart-form');
      if ($form.hasClass('quick-shop-form')) {
        return;
      }
      var $btn = $(this);
      $btn.addClass('loading');
      var data = $form.serializeArray();
      data.push({
        name: 'checkout',
        value: $btn.prop('name') === 'checkout' ? 1 : 0
      });
      $.ajax({
        type: 'POST',
        url: $form.prop('action'),
        data: $.param(data),
        success: function success(res) {
          if (res.error) {
            MartApp.showError(res.message);
            if (res.data && res.data.next_url !== undefined) {
              setTimeout(function () {
                window.location.href = res.data.next_url;
              }, 500);
            }
            return false;
          }
          if (res.data && res.data.next_url !== undefined) {
            window.location.href = res.data.next_url;
            return false;
          }
          MartApp.showSuccess(res.message);
          MartApp.loadAjaxCart();
        },
        error: function error(res) {
          MartApp.handleError(res, $form);
        },
        complete: function complete() {
          $btn.removeClass('loading');
        }
      });
    });
  };
  MartApp.applyCouponCode = function () {
    $(document).on('keypress', '.form-coupon-wrapper .coupon-code', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        e.stopPropagation();
        $(e.currentTarget).closest('.form-coupon-wrapper').find('.btn-apply-coupon-code').trigger('click');
        return false;
      }
    });
    $(document).on('click', '.btn-apply-coupon-code', function (e) {
      e.preventDefault();
      var _self = $(e.currentTarget);
      $.ajax({
        url: _self.data('url'),
        type: 'POST',
        data: {
          coupon_code: _self.closest('.form-coupon-wrapper').find('.coupon-code').val()
        },
        beforeSend: function beforeSend() {
          _self.prop('disabled', true).addClass('loading');
        },
        success: function success(res) {
          if (!res.error) {
            var url = window.location.href;
            url = url.substring(0, url.indexOf('?'));
            $('.cart-page-content').load(url + '?applied_coupon=1 .cart-page-content > *', function () {
              _self.prop('disabled', false).removeClass('loading');
              MartApp.showSuccess(res.message);
            });
          } else {
            MartApp.showError(res.message);
          }
        },
        error: function error(data) {
          MartApp.handleError(data);
        },
        complete: function complete(res) {
          var _res$responseJSON;
          if (!(res.status == 200 && (res === null || res === void 0 || (_res$responseJSON = res.responseJSON) === null || _res$responseJSON === void 0 ? void 0 : _res$responseJSON.error) == false)) {
            _self.prop('disabled', false).removeClass('loading');
          }
        }
      });
    });
    $(document).on('click', '.btn-remove-coupon-code', function (e) {
      e.preventDefault();
      var _self = $(e.currentTarget);
      var buttonText = _self.text();
      _self.text(_self.data('processing-text'));
      $.ajax({
        url: _self.data('url'),
        type: 'POST',
        success: function success(res) {
          if (!res.error) {
            var url = window.location.href;
            url = url.substring(0, url.indexOf('?'));
            $('.cart-page-content').load(url + ' .cart-page-content > *', function () {
              _self.text(buttonText);
            });
          } else {
            MartApp.showError(res.message);
          }
        },
        error: function error(data) {
          MartApp.handleError(data);
        },
        complete: function complete(res) {
          var _res$responseJSON2;
          if (!(res.status == 200 && (res === null || res === void 0 || (_res$responseJSON2 = res.responseJSON) === null || _res$responseJSON2 === void 0 ? void 0 : _res$responseJSON2.error) == false)) {
            _self.text(buttonText);
          }
        }
      });
    });
  };
  MartApp.loadAjaxCart = function () {
    var _window$siteConfig;
    if ((_window$siteConfig = window.siteConfig) !== null && _window$siteConfig !== void 0 && _window$siteConfig.ajaxCart) {
      $.ajax({
        url: window.siteConfig.ajaxCart,
        method: 'GET',
        success: function success(res) {
          if (!res.error) {
            $('.mini-cart-content .widget-shopping-cart-content').html(res.data.html);
            $('.btn-shopping-cart .header-item-counter').text(res.data.count);
            $('.cart--mini .cart-price-total .cart-amount span').text(res.data.total_price);
            $('.menu--footer .icon-cart .cart-counter').text(res.data.count);
            MartApp.lazyLoad($('.mini-cart-content')[0]);
          }
        }
      });
    }
  };
  MartApp.changeInputInSearchForm = function (parseParams) {
    isReadySubmitTrigger = false;
    $(document).find(MartApp.formSearch).find('input, select, textarea').each(function (e, i) {
      var $el = $(i);
      var name = $el.attr('name');
      var value = parseParams[name] || null;
      var type = $el.attr('type');
      switch (type) {
        case 'checkbox':
          $el.prop('checked', false);
          if (Array.isArray(value)) {
            $el.prop('checked', value.includes($el.val()));
          } else {
            $el.prop('checked', !!value);
          }
          break;
        default:
          if ($el.is('[name=max_price]')) {
            $el.val(value || $el.data('max'));
          } else if ($el.is('[name=min_price]')) {
            $el.val(value || $el.data('min'));
          } else if ($el.val() != value) {
            $el.val(value);
          }
          break;
      }
    });
    isReadySubmitTrigger = true;
  };
  MartApp.convertFromDataToArray = function (formData) {
    var data = [];
    formData.forEach(function (obj) {
      if (obj.value) {
        if (['min_price', 'max_price'].includes(obj.name)) {
          var dataValue = $(document).find(MartApp.formSearch).find('input[name=' + obj.name + ']').data(obj.name.substring(0, 3));
          if (dataValue == parseInt(obj.value)) {
            return;
          }
        }
        data.push(obj);
      }
    });
    return data;
  };
  var isReadySubmitTrigger = true;
  MartApp.productsFilter = function () {
    $('.catalog-toolbar__ordering input[name=sort-by]').on('change', function (e) {
      $(document).find(MartApp.formSearch).find('input[name=sort-by]').val($(e.currentTarget).val());
      $(document).find(MartApp.formSearch).trigger('submit');
    });
    MartApp.$body.on('click', '.cat-menu-close', function (e) {
      e.preventDefault();
      $(this).closest('li').toggleClass('opened');
    });
  };
  MartApp.parseParamsSearch = function (query) {
    var includeArray = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    var pairs = query || window.location.search.substring(1);
    var re = /([^&=]+)=?([^&]*)/g;
    var decodeRE = /\+/g;
    var decode = function decode(str) {
      return decodeURIComponent(str.replace(decodeRE, ' '));
    };
    var params = {},
      e;
    while (e = re.exec(pairs)) {
      var k = decode(e[1]),
        v = decode(e[2]);
      if (k.substring(k.length - 2) == '[]') {
        if (includeArray) {
          k = k.substring(0, k.length - 2);
        }
        ;
        (params[k] || (params[k] = [])).push(v);
      } else params[k] = v;
    }
    return params;
  };
  MartApp.processUpdateCart = function ($this) {
    var $form = $('.cart-page-content').find('.form--shopping-cart');
    if (!$form.length) {
      return false;
    }
    $.ajax({
      type: 'POST',
      cache: false,
      url: $form.prop('action'),
      data: new FormData($form[0]),
      contentType: false,
      processData: false,
      beforeSend: function beforeSend() {
        $this.addClass('loading');
      },
      success: function success(res) {
        if (res.error) {
          MartApp.showError(res.message);
          return false;
        }
        $('.cart-page-content').load(window.siteConfig.cartUrl + ' .cart-page-content > *', function () {
          MartApp.lazyLoad($('.cart-page-content')[0]);
        });
        MartApp.loadAjaxCart();
        MartApp.showSuccess(res.message);
      },
      error: function error(res) {
        $this.closest('.ps-table--shopping-cart').removeClass('content-loading');
        MartApp.handleError(res);
      },
      complete: function complete() {
        $this.removeClass('loading');
      }
    });
  };
  MartApp.ajaxUpdateCart = function (_self) {
    $(document).on('click', '.cart-page-content .update_cart', function (e) {
      e.preventDefault();
      var $this = $(e.currentTarget);
      MartApp.processUpdateCart($this);
    });
  };
  MartApp.removeCartItem = function () {
    $(document).on('click', '.remove-cart-item', function (event) {
      event.preventDefault();
      var _self = $(this);
      $.ajax({
        url: _self.data('url'),
        method: 'GET',
        beforeSend: function beforeSend() {
          _self.addClass('loading');
        },
        success: function success(res) {
          var _window$siteConfig2;
          if (res.error) {
            MartApp.showError(res.message);
            return false;
          }
          var $cartContent = $('.cart-page-content');
          if ($cartContent.length && (_window$siteConfig2 = window.siteConfig) !== null && _window$siteConfig2 !== void 0 && _window$siteConfig2.cartUrl) {
            $cartContent.load(window.siteConfig.cartUrl + ' .cart-page-content > *', function () {
              MartApp.lazyLoad($cartContent[0]);
            });
          }
          MartApp.loadAjaxCart();
        },
        error: function error(res) {
          MartApp.handleError(res);
        },
        complete: function complete() {
          _self.removeClass('loading');
        }
      });
    });
  };
  MartApp.removeWishlistItem = function () {
    $(document).on('click', '.remove-wishlist-item', function (event) {
      event.preventDefault();
      var _self = $(this);
      $.ajax({
        url: _self.data('url'),
        method: 'POST',
        data: {
          _method: 'DELETE'
        },
        beforeSend: function beforeSend() {
          _self.addClass('loading');
        },
        success: function success(res) {
          if (res.error) {
            MartApp.showError(res.message);
          } else {
            MartApp.showSuccess(res.message);
            $('.btn-wishlist .header-item-counter').text(res.data.count);
            _self.closest('tr').remove();
          }
        },
        error: function error(res) {
          MartApp.handleError(res);
        },
        complete: function complete() {
          _self.removeClass('loading');
        }
      });
    });
  };
  MartApp.removeCompareItem = function () {
    $(document).on('click', '.remove-compare-item', function (event) {
      event.preventDefault();
      var _self = $(this);
      $.ajax({
        url: _self.data('url'),
        method: 'POST',
        data: {
          _method: 'DELETE'
        },
        beforeSend: function beforeSend() {
          _self.addClass('loading');
        },
        success: function success(res) {
          if (res.error) {
            MartApp.showError(res.message);
          } else {
            MartApp.showSuccess(res.message);
            $('.btn-compare .header-item-counter').text(res.data.count);
            $('.compare-page-content').load(window.location.href + ' .compare-page-content > *');
          }
        },
        error: function error(res) {
          MartApp.handleError(res);
        },
        complete: function complete() {
          _self.removeClass('loading');
        }
      });
    });
  };
  MartApp.handleTabBootstrap = function () {
    var hash = window.location.hash;
    if (hash) {
      var tabTriggerEl = $('a[href="' + hash + '"]');
      if (tabTriggerEl.length) {
        var tab = new bootstrap.Tab(tabTriggerEl[0]);
        tab.show();
      }
    }
  };
  MartApp.filterSlider = function () {
    $(document).find('.nonlinear').each(function (index, element) {
      var $element = $(element);
      var min = $element.data('min');
      var max = $element.data('max');
      var $wrapper = $(element).closest('.nonlinear-wrapper');
      noUiSlider.create(element, {
        connect: true,
        behaviour: 'tap',
        start: [$wrapper.find('.product-filter-item-price-0').val(), $wrapper.find('.product-filter-item-price-1').val()],
        range: {
          min: min,
          '10%': max * 0.1,
          '20%': max * 0.2,
          '30%': max * 0.3,
          '40%': max * 0.4,
          '50%': max * 0.5,
          '60%': max * 0.6,
          '70%': max * 0.7,
          '80%': max * 0.8,
          '90%': max * 0.9,
          max: max
        }
      });
      var nodes = [$wrapper.find('.slider__min'), $wrapper.find('.slider__max')];
      element.noUiSlider.on('update', function (values, handle) {
        nodes[handle].html(EcommerceApp.formatPrice(Math.round(values[handle])));
      });
      element.noUiSlider.on('change', function (values, handle) {
        $wrapper.find('.product-filter-item-price-' + handle).val(Math.round(values[handle])).trigger('change');
      });
    });
  };
  MartApp.customerDashboard = function () {
    if ($.fn.datepicker) {
      $('#date_of_birth').datepicker({
        format: 'yyyy-mm-dd',
        orientation: 'bottom'
      });
    }
    $('#avatar').on('change', function (event) {
      var input = event.currentTarget;
      if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
          $('.userpic-avatar').attr('src', e.target.result);
        };
        reader.readAsDataURL(input.files[0]);
      }
    });
    $(document).on('click', '.btn-trigger-delete-address', function (event) {
      event.preventDefault();
      $('.btn-confirm-delete').data('url', $(this).data('url'));
      $('#confirm-delete-modal').modal('show');
    });
    $(document).on('click', '.btn-confirm-delete', function (event) {
      event.preventDefault();
      var $current = $(this);
      $.ajax({
        url: $current.data('url'),
        type: 'GET',
        beforeSend: function beforeSend() {
          $current.addClass('loading');
        },
        success: function success(res) {
          $current.closest('.modal').modal('hide');
          if (res.error) {
            MartApp.showError(res.message);
          } else {
            MartApp.showSuccess(res.message);
            $('.btn-trigger-delete-address[data-url="' + $current.data('url') + '"]').closest('.col').remove();
          }
        },
        error: function error(res) {
          MartApp.handleError(res);
        },
        complete: function complete() {
          $current.removeClass('loading');
        }
      });
    });
  };
  MartApp.newsletterForm = function () {
    $(document).on('submit', 'form.subscribe-form', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var $this = $(e.currentTarget);
      var _self = $this.find('button[type=submit]');
      $.ajax({
        type: 'POST',
        cache: false,
        url: $this.prop('action'),
        data: new FormData($this[0]),
        contentType: false,
        processData: false,
        beforeSend: function beforeSend() {
          _self.prop('disabled', true).addClass('button-loading');
        },
        success: function success(res) {
          if (typeof refreshRecaptcha !== 'undefined') {
            refreshRecaptcha();
          }
          if (!res.error) {
            $this.find('input[type=email]').val('');
            MartApp.showSuccess(res.message);
          } else {
            MartApp.showError(res.message);
          }
        },
        error: function error(res) {
          if (typeof refreshRecaptcha !== 'undefined') {
            refreshRecaptcha();
          }
          MartApp.handleError(res);
        },
        complete: function complete() {
          _self.prop('disabled', false).removeClass('button-loading');
        }
      });
    });
  };
  MartApp.contactSellerForm = function () {
    $(document).on('click', 'form.form-contact-store button[type=submit]', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var $this = $(e.currentTarget);
      var $form = $this.closest('form');
      $.ajax({
        type: 'POST',
        cache: false,
        url: $form.prop('action'),
        data: new FormData($form[0]),
        contentType: false,
        processData: false,
        beforeSend: function beforeSend() {
          $this.prop('disabled', true).addClass('button-loading');
        },
        success: function success(res) {
          if (typeof refreshRecaptcha !== 'undefined') {
            refreshRecaptcha();
          }
          if (!res.error) {
            $form.find('input[type=email]:not(:disabled)').val('');
            $form.find('input[type=text]:not(:disabled)').val('');
            $form.find('textarea').val('');
            MartApp.showSuccess(res.message);
          } else {
            MartApp.showError(res.message);
          }
        },
        error: function error(res) {
          if (typeof refreshRecaptcha !== 'undefined') {
            refreshRecaptcha();
          }
          MartApp.handleError(res);
        },
        complete: function complete() {
          $this.prop('disabled', false).removeClass('button-loading');
        }
      });
    });
  };
  MartApp.recentlyViewedProducts = function () {
    MartApp.$body.find('.header-recently-viewed').each(function () {
      var $el = $(this);
      var loading;
      $el.hover(function () {
        var $recently = $el.find('.recently-viewed-products');
        if ($el.data('loaded') || loading) {
          return;
        }
        var url = $el.data('url');
        if (!url) {
          return;
        }
        $.ajax({
          type: 'GET',
          url: url,
          beforeSend: function beforeSend() {
            loading = true;
          },
          success: function success(res) {
            if (!res.error) {
              $recently.html(res.data);
              if ($recently.find('.product-list li').length > 0) {
                MartApp.slickSlide($recently.find('.product-list'));
              }
              $el.data('loaded', true).find('.loading--wrapper').addClass('d-none');
            } else {
              MartApp.showError(res.message);
            }
          },
          error: function error(res) {
            MartApp.handleError(res);
          },
          complete: function complete() {
            loading = false;
          }
        });
      });
    });
  };
  MartApp.showNotice = function (messageType, message) {
    Theme.showNotice(messageType, message);
  };
  MartApp.showError = function (message) {
    Theme.showError(message);
  };
  MartApp.showSuccess = function (message) {
    Theme.showSuccess(message);
  };
  MartApp.handleError = function (data) {
    Theme.handleError(data);
  };
  MartApp.handleValidationError = function (errors) {
    Theme.handleValidationError(errors);
  };
  MartApp.toggleViewProducts = function () {
    $(document).on('click', '.store-list-filter-button', function (e) {
      e.preventDefault();
      $('#store-listing-filter-form-wrap').toggle(500);
    });
    MartApp.$body.on('click', '.products-layout a', function (e) {
      e.preventDefault();
      var $this = $(e.currentTarget);
      $this.closest('.products-layout').find('li').removeClass('active');
      $this.closest('li').addClass('active');
      $($this.data('target')).removeClass($this.data('class-remove')).addClass($this.data('class-add'));
      $(document).find(MartApp.formSearch).find('input[name=layout]').val($this.data('layout'));
      var params = new URLSearchParams(window.location.search);
      params.set('layout', $this.data('layout'));
      var nextHref = window.location.protocol + '//' + window.location.host + window.location.pathname + '?' + params.toString();
      if (nextHref != window.location.href) {
        window.history.pushState(MartApp.$productListing.html(), '', nextHref);
      }
    });
  };
  MartApp.toolbarOrderingProducts = function () {
    MartApp.$body.on('click', '.catalog-toolbar__ordering .dropdown .dropdown-menu a', function (e) {
      e.preventDefault();
      var $this = $(e.currentTarget);
      var $parent = $this.closest('.dropdown');
      $parent.find('li').removeClass('active');
      $this.closest('li').addClass('active');
      $parent.find('a[data-bs-toggle=dropdown').html($this.html());
      $this.closest('.catalog-toolbar__ordering').find('input[name=sort-by]').val($this.data('value')).trigger('change');
    });
  };
  MartApp.backToTop = function () {
    var scrollPos = 0;
    var element = $('#back2top');
    $(window).scroll(function () {
      var scrollCur = $(window).scrollTop();
      if (scrollCur > scrollPos) {
        if (scrollCur > 500) {
          element.addClass('active');
        } else {
          element.removeClass('active');
        }
      } else {
        element.removeClass('active');
      }
      scrollPos = scrollCur;
    });
    element.on('click', function () {
      $('html, body').animate({
        scrollTop: '0px'
      }, 0);
    });
  };
  MartApp.initMegaMenu = function () {
    setTimeout(function () {
      var $megaMenu = $(document).find('.mega-menu-wrapper');
      if (!$megaMenu.length) {
        return;
      }
      if ($(window).width() > 1200 && typeof $.fn.masonry !== 'undefined') {
        $megaMenu.masonry({
          itemSelector: '.mega-menu__column',
          columnWidth: 200
        });
      }
    }, 500);
  };
  MartApp.stickyHeader = function () {
    var header = $('.header-js-handler');
    var checkpoint = header.height();
    header.each(function () {
      if ($(this).data('sticky') === true) {
        var el = $(this);
        $(window).scroll(function () {
          var currentPosition = $(this).scrollTop();
          if (currentPosition > checkpoint) {
            el.addClass('header--sticky');
            MartApp.initMegaMenu();
          } else {
            el.removeClass('header--sticky');
          }
        });
      }
    });
  };
  MartApp.stickyAddToCart = function () {
    var $headerProduct = $('.header--product');
    $(window).scroll(function () {
      var currentPosition = $(this).scrollTop();
      if (currentPosition > 50) {
        $headerProduct.addClass('header--sticky');
      } else {
        $headerProduct.removeClass('header--sticky');
      }
    });
    $('.header--product ul li > a ').on('click', function (e) {
      e.preventDefault();
      var target = $(this).attr('href');
      $(this).closest('li').siblings('li').removeClass('active');
      $(this).closest('li').addClass('active');
      $(target).closest('.product-detail-tabs').find('a').removeClass('active');
      $(target).addClass('active');
      $('.header--product ul li').removeClass('active');
      $('.header--product ul li a[href="' + target + '"]').closest('li').addClass('active');
      $('#product-detail-tabs-content > .tab-pane').removeClass('active show');
      $($(target).attr('href')).addClass('active show');
      $('html, body').animate({
        scrollTop: $(target).offset().top - $('.header--product .navigation').height() - 165 + 'px'
      }, 0);
    });
    var $trigger = $('.product-details .entry-product-header'),
      $stickyBtn = $('.sticky-atc-wrap');
    if ($stickyBtn.length && $trigger.length && $(window).width() < 768) {
      var summaryOffset = $trigger.offset().top + $trigger.outerHeight(),
        _footer = $('.footer-mobile'),
        off_footer = 0,
        ck_footer = _footer.length > 0;
      var stickyAddToCartToggle = function stickyAddToCartToggle() {
        var windowScroll = $(window).scrollTop(),
          windowHeight = $(window).height(),
          documentHeight = $(document).height();
        if (ck_footer) {
          off_footer = _footer.offset().top - _footer.height();
        } else {
          off_footer = windowScroll;
        }
        if (windowScroll + windowHeight === documentHeight || summaryOffset > windowScroll || windowScroll > off_footer) {
          $stickyBtn.removeClass('sticky-atc-shown');
        } else if (summaryOffset < windowScroll && windowScroll + windowHeight !== documentHeight) {
          $stickyBtn.addClass('sticky-atc-shown');
        }
      };
      stickyAddToCartToggle();
      $(window).scroll(stickyAddToCartToggle);
    }
  };
  $(function () {
    MartApp.init();
    window.onBeforeChangeSwatches = function (data, $attrs) {
      var $product = $attrs.closest('.product-details').length ? $attrs.closest('.product-details') : $attrs.closest('.ps-product--quickshop');
      var $form = $product.find('.cart-form');
      $product.find('.error-message').hide();
      $product.find('.success-message').hide();
      $product.find('.number-items-available').html('').hide();
      var $submit = $form.find('button[type=submit]');
      $submit.addClass('loading');
      if (data && data.attributes) {
        $submit.prop('disabled', true);
      }
    };
    window.onChangeSwatchesSuccess = function (res, $attrs) {
      var $product = $attrs.closest('.product-details').length ? $attrs.closest('.product-details') : $attrs.closest('.ps-product--quickshop');
      var $form = $product.find('.cart-form');
      var $footerCartForm = $('.footer-cart-form');
      $product.find('.error-message').hide();
      $product.find('.success-message').hide();
      if (res) {
        var $submit = $form.find('button[type=submit]');
        $submit.removeClass('loading');
        if (res.error) {
          $submit.prop('disabled', true);
          $product.find('.number-items-available').html('<span class="text-danger">(' + res.message + ')</span>').show();
          $form.find('.hidden-product-id').val('');
          $footerCartForm.find('.hidden-product-id').val('');
        } else {
          var data = res.data;
          var $priceContainer = $product.find('.ps-product__header').length ? $product.find('.ps-product__header') : $(document).find('.js-product-content');
          var $salePrice = $priceContainer.find('.product-price-sale');
          var $originalPrice = $priceContainer.find('.product-price-original');
          if (data.sale_price !== data.price) {
            $salePrice.removeClass('d-none');
            $originalPrice.addClass('d-none');
          } else {
            $salePrice.addClass('d-none');
            $originalPrice.removeClass('d-none');
          }
          $salePrice.find('ins .amount').text(data.display_sale_price);
          $salePrice.find('del .amount').text(data.display_price);
          $originalPrice.find('.amount').text(data.display_sale_price);
          if (data.sku) {
            $product.find('.meta-sku .meta-value').text(data.sku);
            $product.find('.meta-sku').removeClass('d-none');
          } else {
            $product.find('.meta-sku').addClass('d-none');
          }
          $form.find('.hidden-product-id').val(data.id);
          $footerCartForm.find('.hidden-product-id').val(data.id);
          $submit.prop('disabled', false);
          if (data.error_message) {
            $submit.prop('disabled', true);
            $product.find('.number-items-available').html('<span class="text-danger">(' + data.error_message + ')</span>').show();
          } else if (data.success_message) {
            $product.find('.number-items-available').html(res.data.stock_status_html).show();
            $product.find('.product-quantity-available').text(res.data.success_message);
            $product.find('.out-of-stock').removeClass('out-of-stock');
          } else {
            $product.find('.number-items-available').html('').hide();
          }
          $product.find('.bb-product-attribute-swatch-item').removeClass('disabled');
          $product.find('.bb-product-attribute-swatch-list select option').prop('disabled', false);
          var unavailableAttributeIds = data.unavailable_attribute_ids || [];
          if (unavailableAttributeIds.length) {
            unavailableAttributeIds.map(function (id) {
              var $swatchItem = $product.find(".bb-product-attribute-swatch-item[data-id=\"".concat(id, "\"]"));
              if ($swatchItem.length) {
                $swatchItem.addClass('disabled');
                $swatchItem.find('input').prop('checked', false);
              } else {
                $swatchItem = $product.find(".bb-product-attribute-swatch-list select option[data-id=\"".concat(id, "\"]"));
                if ($swatchItem.length) {
                  $swatchItem.prop('disabled', true);
                }
              }
            });
          }
          var imageHtml = '';
          var thumbHtml = '';
          if (!data.image_with_sizes.origin.length) {
            data.image_with_sizes.origin.push(siteConfig.img_placeholder);
          } else {
            data.image_with_sizes.origin.forEach(function (item) {
              imageHtml += "\n                    <a href='".concat(item, "'>\n                        <img src='").concat(item, "' alt='").concat(data.name, "'>\n                    </a>\n                ");
            });
          }
          if (!data.image_with_sizes.thumb.length) {
            data.image_with_sizes.thumb.push(siteConfig.img_placeholder);
          } else {
            data.image_with_sizes.thumb.forEach(function (item) {
              thumbHtml += "\n                    <div>\n                        <img src='".concat(item, "' alt='").concat(data.name, "'>\n                    </div>\n                ");
            });
          }
          var $galleryImages = $(document).find('.bb-product-gallery-wrapper');
          $galleryImages.find('.bb-product-gallery-thumbnails').slick('unslick').html(thumbHtml);
          var $quickViewGalleryImages = $(document).find('.bb-quick-view-gallery-images');
          if ($quickViewGalleryImages.length) {
            $quickViewGalleryImages.slick('unslick').html(imageHtml);
          }
          $galleryImages.find('.bb-product-gallery-images').slick('unslick').html(imageHtml);
          if (typeof EcommerceApp !== 'undefined') {
            EcommerceApp.initProductGallery();
          }
        }
      }
    };
    if (jQuery().mCustomScrollbar) {
      $(document).find('.ps-custom-scrollbar').mCustomScrollbar({
        theme: 'dark',
        scrollInertia: 0
      });
    }
    $(document).on('click', '.toggle-show-more', function (event) {
      event.preventDefault();
      $('#store-short-description').fadeOut();
      $(this).addClass('d-none');
      $('#store-content').removeClass('d-none').slideDown(500);
      $('.toggle-show-less').removeClass('d-none');
    });
    $(document).on('click', '.toggle-show-less', function (event) {
      event.preventDefault();
      $(this).addClass('d-none');
      $('#store-content').slideUp(500).addClass('d-none');
      $('#store-short-description').fadeIn();
      $('.toggle-show-more').removeClass('d-none');
    });
    var collapseBreadcrumb = function collapseBreadcrumb() {
      $('.page-breadcrumbs ol li').each(function () {
        var $this = $(this);
        if (!$this.is(':first-child') && !$this.is(':nth-child(2)') && !$this.is(':last-child')) {
          if (!$this.is(':nth-child(3)')) {
            $this.find('a').closest('li').hide();
          } else {
            $this.find('a').hide();
            $this.find('.extra-breadcrumb-name').text('...').show();
          }
        }
      });
    };
    if ($(window).width() < 768) {
      collapseBreadcrumb();
    }
    $(window).on('resize', function () {
      collapseBreadcrumb();
    });
    $('.product-entry-meta .anchor-link').on('click', function (e) {
      e.preventDefault();
      var target = $(this).attr('href');
      $('#product-detail-tabs a').removeClass('active');
      $(target).addClass('active');
      $('#product-detail-tabs-content > .tab-pane').removeClass('active show');
      $($(target).attr('href')).addClass('active show');
      $('html, body').animate({
        scrollTop: $(target).offset().top - $('.header--product .navigation').height() - 250 + 'px'
      }, 0);
    });
    $(document).on('click', '#sticky-add-to-cart .add-to-cart-button', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var $this = $(e.currentTarget);
      $this.addClass('button-loading');
      setTimeout(function () {
        var target = '.js-product-content .cart-form button[name=' + $this.prop('name') + '].add-to-cart-button';
        $(document).find(target).trigger('click');
        $this.removeClass('button-loading');
      }, 200);
    });
    $(document).ready(function () {
      MartApp.initMegaMenu();
    });
    document.addEventListener('ecommerce.product-filter.before', function () {
      MartApp.$productListing.find('.loading').show();
    });
    document.addEventListener('ecommerce.product-filter.completed', function () {
      MartApp.lazyLoad(MartApp.$productListing[0]);
    });
    document.addEventListener('ecommerce.categories-dropdown.success', function () {
      MartApp.initMegaMenu();
    });
    document.addEventListener('ecommerce.quick-shop.completed', function (e) {
      var modal = e.detail.modal;
      if (modal && modal.length) {
        MartApp.initQuickShopVariationListeners(modal);
      }
    });
    document.addEventListener('shortcode.loaded', function (e) {
      requestAnimationFrame(function () {
        setTimeout(function () {
          try {
            if (typeof MartApp.safeSlickInit === 'function') {
              MartApp.safeSlickInit('.slick-slides-carousel');
              MartApp.safeSlickInit('.owl-slider');
            } else {
              if (typeof MartApp.slickSlides === 'function') {
                MartApp.slickSlides();
              }
            }
            var loadedElements = document.querySelectorAll('.shortcode-lazy-loading-loaded');
            if (loadedElements.length > 0) {
              loadedElements.forEach(function (container) {
                if (container && typeof MartApp.lazyLoad === 'function') {
                  MartApp.lazyLoad(container, false);
                }
                container.classList.remove('shortcode-lazy-loading-loaded');
              });
            } else {
              if (typeof MartApp.lazyLoadInstance !== 'undefined' && MartApp.lazyLoadInstance) {
                MartApp.lazyLoadInstance.update();
              }
            }
            if (typeof MartApp.slickSlides === 'function') {
              MartApp.slickSlides();
            }
            if (typeof MartApp.initCountdowns === 'function') {
              MartApp.initCountdowns();
            }
          } catch (error) {
            console.error('Error re-initializing components after shortcode load:', error);
          }
        }, 300);
      });
    });
  });

  // -------------- JScover Customer By TIVATECH  ------------------

  //  Hình ảnh thực tế
  document.addEventListener('DOMContentLoaded', function () {
    var $gallery = $('#gallery-light');

    // Tùy theo màn hình, chọn rowHeight khác nhau
    var isMobile = window.innerWidth < 768; // hoặc 576 tùy bạn

    var lgZoom = window.lgZoom;
    var lgThumbnail = window.lgThumbnail;
    $gallery.justifiedGallery({
      rowHeight: isMobile ? 150 : 250,
      // 👈 nhỏ hơn trên mobile
      margins: 10,
      captions: false,
      waitThumbnailsLoad: true,
      lastRow: 'nojustify'
    }).on('jg.complete', function () {
      setTimeout(function () {
        if (!$gallery[0].lg) {
          lightGallery($gallery[0], {
            selector: '.gallery-item',
            plugins: [lgZoom, lgThumbnail],
            download: false,
            zoom: true,
            thumbnail: true,
            showThumbByDefault: true,
            thumbWidth: 100,
            thumbHeight: 'auto',
            animateThumb: true,
            toggleThumb: true,
            on: {
              lgAfterOpen: function lgAfterOpen() {
                window.dispatchEvent(new Event('resize'));
              }
            }
          });
        }
      }, 100);
    });
  });
})(jQuery);

/***/ }),

/***/ "./platform/themes/farmart/assets/sass/style-rtl.scss":
/*!************************************************************!*\
  !*** ./platform/themes/farmart/assets/sass/style-rtl.scss ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./platform/themes/farmart/assets/sass/style.scss":
/*!********************************************************!*\
  !*** ./platform/themes/farmart/assets/sass/style.scss ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./public/vendor/core/core/base/css/core.css":
/*!***************************************************!*\
  !*** ./public/vendor/core/core/base/css/core.css ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./public/vendor/core/core/base/css/libraries/select2.css":
/*!****************************************************************!*\
  !*** ./public/vendor/core/core/base/css/libraries/select2.css ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"/themes/farmart/js/main": 0,
/******/ 			"vendor/core/plugins/toc/css/toc": 0,
/******/ 			"vendor/core/plugins/translation/css/translation": 0,
/******/ 			"themes/farmart/css/style-rtl": 0,
/******/ 			"vendor/core/core/base/css/libraries/select2.rtl": 0,
/******/ 			"vendor/core/core/base/css/core.rtl": 0,
/******/ 			"themes/farmart/css/style": 0,
/******/ 			"vendor/core/core/base/css/crop-image": 0,
/******/ 			"vendor/core/core/base/css/tree-category": 0,
/******/ 			"vendor/core/core/base/css/error-pages": 0,
/******/ 			"vendor/core/core/base/css/libraries/select2": 0,
/******/ 			"vendor/core/core/base/css/core": 0,
/******/ 			"vendor/core/core/media/css/media": 0,
/******/ 			"vendor/core/core/setting/css/admin-email": 0,
/******/ 			"vendor/core/core/table/css/table": 0,
/******/ 			"vendor/core/packages/get-started/css/get-started": 0,
/******/ 			"vendor/core/packages/installer/css/style": 0,
/******/ 			"vendor/core/packages/menu/css/menu": 0,
/******/ 			"vendor/core/packages/revision/css/revision": 0,
/******/ 			"vendor/core/packages/seo-helper/css/seo-helper": 0,
/******/ 			"vendor/core/packages/shortcode/css/shortcode": 0,
/******/ 			"vendor/core/packages/slug/css/slug": 0,
/******/ 			"vendor/core/packages/theme/css/guideline": 0,
/******/ 			"vendor/core/packages/theme/css/admin-bar": 0,
/******/ 			"vendor/core/packages/theme/css/theme-options": 0,
/******/ 			"vendor/core/packages/widget/css/widget": 0,
/******/ 			"vendor/core/plugins/backup/css/backup": 0,
/******/ 			"vendor/core/plugins/contact/css/contact-public": 0,
/******/ 			"vendor/core/plugins/contact/css/contact": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-theme-rtl": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-theme": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-review": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-faq": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-ecommerce-rtl": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-ecommerce": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/front-auth": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/widget": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/order-return": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/report": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/customer": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/review": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/currencies": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/ecommerce-product-attributes": 0,
/******/ 			"vendor/core/plugins/ecommerce/css/ecommerce": 0,
/******/ 			"vendor/core/plugins/faq/css/faq": 0,
/******/ 			"vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons": 0,
/******/ 			"vendor/core/plugins/language/css/language-public": 0,
/******/ 			"vendor/core/plugins/language/css/language": 0,
/******/ 			"vendor/core/plugins/log-viewer/css/log-viewer": 0,
/******/ 			"vendor/core/plugins/marketplace/css/marketplace-rtl": 0,
/******/ 			"vendor/core/plugins/marketplace/css/marketplace": 0,
/******/ 			"vendor/core/plugins/newsletter/css/newsletter": 0,
/******/ 			"vendor/core/plugins/payment/css/payment-setting": 0,
/******/ 			"vendor/core/plugins/payment/css/payment": 0,
/******/ 			"vendor/core/plugins/simple-slider/css/simple-slider": 0,
/******/ 			"vendor/core/plugins/social-login/css/social-login": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunk"] = self["webpackChunk"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/themes/farmart/assets/js/main.js")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/themes/farmart/assets/sass/style.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/themes/farmart/assets/sass/style-rtl.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/translation/resources/sass/translation.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/toc/resources/assets/sass/toc.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/social-login/resources/sass/social-login.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/simple-slider/resources/sass/simple-slider.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/payment/resources/sass/payment.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/payment/resources/sass/payment-setting.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/newsletter/resources/sass/newsletter.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/marketplace/resources/sass/vendor-dashboard/marketplace.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/marketplace/resources/sass/vendor-dashboard/marketplace-rtl.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/log-viewer/resources/assets/sass/log-viewer.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/language/resources/sass/language.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/language/resources/sass/language-public.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/fob-floating-buttons/resources/sass/fob-floating-buttons.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/faq/resources/sass/faq.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/ecommerce.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/ecommerce-product-attributes.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/currencies.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/review.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/customer.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/report.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/order-return.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/widget.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-auth.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-ecommerce.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-ecommerce-missing-bootstrap.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-ecommerce-rtl.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-faq.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-review.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-theme.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/ecommerce/resources/sass/front-theme-rtl.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/contact/resources/sass/contact.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/contact/resources/sass/contact-public.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/plugins/backup/resources/sass/backup.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/packages/widget/resources/sass/widget.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/packages/theme/resources/sass/theme-options.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/packages/theme/resources/sass/admin-bar.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/packages/theme/resources/sass/guideline.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/packages/slug/resources/sass/slug.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/packages/shortcode/resources/sass/shortcode.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/packages/seo-helper/resources/sass/seo-helper.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/packages/revision/resources/sass/revision.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/packages/menu/resources/sass/menu.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/packages/installer/resources/sass/style.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/packages/get-started/resources/sass/get-started.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/core/table/resources/sass/table.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/core/setting/resources/sass/admin-email.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/core/media/resources/sass/media.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/core/base/resources/sass/core.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/core/base/resources/sass/libraries/select2/select2.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/core/base/resources/sass/components/error-pages.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/core/base/resources/sass/components/tree-category.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./platform/core/base/resources/sass/components/crop-image.scss")))
/******/ 	__webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./public/vendor/core/core/base/css/core.css")))
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendor/core/plugins/toc/css/toc","vendor/core/plugins/translation/css/translation","themes/farmart/css/style-rtl","vendor/core/core/base/css/libraries/select2.rtl","vendor/core/core/base/css/core.rtl","themes/farmart/css/style","vendor/core/core/base/css/crop-image","vendor/core/core/base/css/tree-category","vendor/core/core/base/css/error-pages","vendor/core/core/base/css/libraries/select2","vendor/core/core/base/css/core","vendor/core/core/media/css/media","vendor/core/core/setting/css/admin-email","vendor/core/core/table/css/table","vendor/core/packages/get-started/css/get-started","vendor/core/packages/installer/css/style","vendor/core/packages/menu/css/menu","vendor/core/packages/revision/css/revision","vendor/core/packages/seo-helper/css/seo-helper","vendor/core/packages/shortcode/css/shortcode","vendor/core/packages/slug/css/slug","vendor/core/packages/theme/css/guideline","vendor/core/packages/theme/css/admin-bar","vendor/core/packages/theme/css/theme-options","vendor/core/packages/widget/css/widget","vendor/core/plugins/backup/css/backup","vendor/core/plugins/contact/css/contact-public","vendor/core/plugins/contact/css/contact","vendor/core/plugins/ecommerce/css/front-theme-rtl","vendor/core/plugins/ecommerce/css/front-theme","vendor/core/plugins/ecommerce/css/front-review","vendor/core/plugins/ecommerce/css/front-faq","vendor/core/plugins/ecommerce/css/front-ecommerce-rtl","vendor/core/plugins/ecommerce/css/front-ecommerce-missing-bootstrap","vendor/core/plugins/ecommerce/css/front-ecommerce","vendor/core/plugins/ecommerce/css/front-auth","vendor/core/plugins/ecommerce/css/widget","vendor/core/plugins/ecommerce/css/order-return","vendor/core/plugins/ecommerce/css/report","vendor/core/plugins/ecommerce/css/customer","vendor/core/plugins/ecommerce/css/review","vendor/core/plugins/ecommerce/css/currencies","vendor/core/plugins/ecommerce/css/ecommerce-product-attributes","vendor/core/plugins/ecommerce/css/ecommerce","vendor/core/plugins/faq/css/faq","vendor/core/plugins/fob-floating-buttons/css/fob-floating-buttons","vendor/core/plugins/language/css/language-public","vendor/core/plugins/language/css/language","vendor/core/plugins/log-viewer/css/log-viewer","vendor/core/plugins/marketplace/css/marketplace-rtl","vendor/core/plugins/marketplace/css/marketplace","vendor/core/plugins/newsletter/css/newsletter","vendor/core/plugins/payment/css/payment-setting","vendor/core/plugins/payment/css/payment","vendor/core/plugins/simple-slider/css/simple-slider","vendor/core/plugins/social-login/css/social-login"], () => (__webpack_require__("./public/vendor/core/core/base/css/libraries/select2.css")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;